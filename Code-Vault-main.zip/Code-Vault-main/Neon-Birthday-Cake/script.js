document.addEventListener("DOMContentLoaded", () => {
    
    gsap.set([".plate", ".sponge1", ".sponge2", ".sponge3", ".candle"], { y: -500, opacity: 0 });
    gsap.set([".filling1", ".filling2", ".icing"], { y: -500, scaleX: 0.4, scaleY: 2, borderRadius: "50%", opacity: 0 });
    gsap.set(".drip", { height: 0, opacity: 0 });
    gsap.set(".flame", { scale: 0, opacity: 0 });
    
    gsap.set(".balloon-bunch", { y: 200, opacity: 0, scale: 0.5 });

    const tl = gsap.timeline({ delay: 0.5 });

    tl.to(".plate", { y: 0, opacity: 1, duration: 0.7, ease: "bounce.out" })
    
    .to(".balloon-bunch", { y: 0, opacity: 1, scale: 1, duration: 1.2, ease: "back.out(1.2)", stagger: 0.2 }, "-=0.5")

    .to(".sponge1", { y: 0, opacity: 1, duration: 0.7, ease: "bounce.out" }, "-=0.8")
    .to(".filling1", { 
        keyframes: [
            { y: 0, scaleX: 0.6, scaleY: 1.4, borderRadius: "50%", opacity: 1, duration: 0.4, ease: "power1.in" },
            { scaleX: 1.1, scaleY: 0.4, borderRadius: "10px", duration: 0.15, ease: "power1.out" },
            { scaleX: 0.95, scaleY: 1.1, borderRadius: "2px", duration: 0.15, ease: "power1.inOut" },
            { scaleX: 1, scaleY: 1, borderRadius: "0px", duration: 0.1, ease: "power1.out" }
        ]
    }, "-=0.5")
    .to(".sponge2", { y: 0, opacity: 1, duration: 0.7, ease: "bounce.out" }, "-=0.5")
    .to(".filling2", { 
        keyframes: [
            { y: 0, scaleX: 0.6, scaleY: 1.4, borderRadius: "50%", opacity: 1, duration: 0.4, ease: "power1.in" },
            { scaleX: 1.1, scaleY: 0.4, borderRadius: "10px", duration: 0.15, ease: "power1.out" },
            { scaleX: 0.95, scaleY: 1.1, borderRadius: "2px", duration: 0.15, ease: "power1.inOut" },
            { scaleX: 1, scaleY: 1, borderRadius: "0px", duration: 0.1, ease: "power1.out" }
        ]
    }, "-=0.5")
    .to(".sponge3", { y: 0, opacity: 1, duration: 0.7, ease: "bounce.out" }, "-=0.5")
    .to(".icing", { 
        keyframes: [
            { y: 0, scaleX: 0.6, scaleY: 1.4, borderRadius: "50%", opacity: 1, duration: 0.4, ease: "power1.in" },
            { scaleX: 1.2, scaleY: 0.4, borderRadius: "10px 10px 5px 5px", duration: 0.15, ease: "power1.out" },
            { scaleX: 0.95, scaleY: 1.1, borderRadius: "6px 6px 2px 2px", duration: 0.15, ease: "power1.inOut" },
            { scaleX: 1, scaleY: 1, duration: 0.1, ease: "power1.out" }
        ]
    }, "-=0.5")
    .to(".drip", { 
        opacity: 1,
        height: (i) => [14, 22, 12, 18][i], 
        duration: 1.5, 
        stagger: 0.25, 
        ease: "power2.out" 
    }, "-=0.1")
    .to(".candle", { 
        keyframes: [
            { y: -500, scaleX: 0.8, scaleY: 1.2, rotation: 15, opacity: 0, duration: 0 },
            { y: 0, scaleX: 0.8, scaleY: 1.2, rotation: -5, opacity: 1, duration: 0.4, ease: "power2.in" },
            { scaleX: 1.4, scaleY: 0.6, rotation: 0, duration: 0.15, ease: "power1.out" },
            { scaleX: 0.9, scaleY: 1.1, duration: 0.15, ease: "power1.inOut" },
            { scaleX: 1, scaleY: 1, duration: 0.1, ease: "power1.out" }
        ]
    }, "<0.1")
    .to(".flame", { 
        scale: 1, opacity: 1, duration: 0.3, ease: "back.out(2)",
        onComplete: () => {
            document.querySelector('.flame').classList.add('flame-flicker');
            startTyping(); 
        }
    }, "<0.6");

    const text = "Happy Birthday my Love!";
    const typedTextElement = document.getElementById("typed-text");
    let charIndex = 0;

    function startTyping() {
        if (charIndex < text.length) {
            typedTextElement.textContent += text.charAt(charIndex);
            charIndex++;
            setTimeout(startTyping, 100);
        } else {
            setTimeout(() => {
                document.getElementById("cursor").style.display = "none";
            }, 2000);
        }
    }

    const canvas = document.getElementById("bgCanvas");
    const ctx = canvas.getContext("2d");
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    window.addEventListener("resize", () => {
        w = canvas.width = window.innerWidth;
        h = window.innerHeight;
    });

    const floatingHearts = [];
    const floatingDots = [];
    
    const colors = ['#00FFFF', '#FF1493', '#FFD700', '#9D00FF', '#ffffff'];

    for (let i = 0; i < 25; i++) {
        floatingHearts.push({
            x: Math.random() * w,
            y: Math.random() * h,
            size: Math.random() * 10 + 6, 
            color: colors[Math.floor(Math.random() * colors.length)],
            speedY: Math.random() * -0.6 - 0.2, 
            speedX: Math.random() * 0.4 - 0.2,  
            opacity: Math.random() * 0.5 + 0.2 
        });
    }

    for (let i = 0; i < 60; i++) {
        floatingDots.push({
            x: Math.random() * w,
            y: Math.random() * h,
            r: Math.random() * 2.5 + 0.5,
            color: colors[Math.floor(Math.random() * colors.length)],
            speedY: Math.random() * -0.5 - 0.1, 
            speedX: Math.random() * 0.4 - 0.2,  
            opacity: Math.random()
        });
    }

    function drawVectorHeart(x, y, size) {
        ctx.beginPath();
        ctx.moveTo(x, y + size / 4);
        ctx.quadraticCurveTo(x, y, x + size / 4, y);
        ctx.quadraticCurveTo(x + size / 2, y, x + size / 2, y + size / 4);
        ctx.quadraticCurveTo(x + size / 2, y, x + size * 3/4, y);
        ctx.quadraticCurveTo(x + size, y, x + size, y + size / 4);
        ctx.quadraticCurveTo(x + size, y + size / 2, x + size / 2, y + size);
        ctx.lineTo(x, y + size / 4);
        ctx.closePath();
    }

    function animateBackground() {
        ctx.clearRect(0, 0, w, h);
        
        floatingDots.forEach(p => {
            p.y += p.speedY;
            p.x += p.speedX;
            
            p.opacity += (Math.random() - 0.5) * 0.05;
            if(p.opacity < 0.1) p.opacity = 0.1;
            if(p.opacity > 1) p.opacity = 1;

            if (p.y < -50) {
                p.y = h + 50;
                p.x = Math.random() * w;
            }

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.opacity;
            ctx.shadowBlur = 8;
            ctx.shadowColor = p.color;
            ctx.fill();
        });

        floatingHearts.forEach(p => {
            p.y += p.speedY;
            p.x += Math.sin(p.y * 0.02) * 0.5; 

            if (p.y < -50) {
                p.y = h + 50;
                p.x = Math.random() * w;
            }

            ctx.globalAlpha = p.opacity;
            ctx.fillStyle = p.color;
            ctx.shadowBlur = 12; 
            ctx.shadowColor = p.color;
            
            drawVectorHeart(p.x, p.y, p.size);
            ctx.fill();
        });

        ctx.globalAlpha = 1;
        requestAnimationFrame(animateBackground);
    }

    animateBackground();
});
